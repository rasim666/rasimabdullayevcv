/* Rasim Abdullayev — GitHub Pages-ready IT portfolio */
const profile = {
  "experiences": [
    {
      "company": {
        "az": "iTicket — Formula 1 Qatar Airways Azerbaijan Grand Prix 2026",
        "en": "iTicket — Formula 1 Qatar Airways Azerbaijan Grand Prix 2026",
        "ru": "iTicket — Formula 1 Qatar Airways Azerbaijan Grand Prix 2026"
      },
      "period": {
        "az": "09.2026 — Frilans",
        "en": "Sep 2026 — Freelance",
        "ru": "09.2026 — Фриланс"
      },
      "role": {
        "az": "Girişə nəzarət üzrə koordinator",
        "en": "Access Coordinator",
        "ru": "Координатор контроля доступа"
      },
      "desc": {
        "az": "Giriş məntəqələrinin idarə edilməsi, könüllülərin koordinasiyası, bilet skanerləri və bilet sistemlərində texniki problemlərin həlli, tamaşaçı axınına nəzarət.",
        "en": "Coordinated access control, supervised volunteers, resolved ticket scanner and ticketing system issues, assisted visitors and monitored spectator flow.",
        "ru": "Координировал контроль доступа и волонтёров, устранял проблемы сканеров и билетных систем, помогал посетителям и контролировал поток зрителей."
      }
    },
    {
      "company": {
        "az": "Azerbaijan Volleyball Federation (AVF) — CEV Trendyol EuroVolley 2026",
        "en": "Azerbaijan Volleyball Federation (AVF) — CEV Trendyol EuroVolley 2026",
        "ru": "Azerbaijan Volleyball Federation (AVF) — CEV Trendyol EuroVolley 2026"
      },
      "period": {
        "az": "07.2026 — 08.2026 · Frilans",
        "en": "Jul – Aug 2026 · Freelance",
        "ru": "07.2026 — 08.2026 · Фриланс"
      },
      "role": {
        "az": "Tribuna meneceri | İdman təqdimatı",
        "en": "Tribune Manager | Sports Presentation",
        "ru": "Менеджер трибун | Спортивная презентация"
      },
      "desc": {
        "az": "Matç günlərində tribuna əməliyyatlarının, matçöncəsi və matç zamanı təqdimat fəaliyyətlərinin koordinasiyası, təşkilati problemlərin həlli və tamaşaçı təcrübəsinin dəstəklənməsi.",
        "en": "Managed tribune operations on match days, coordinated pre-match and in-match presentation activities, resolved organizational issues and supported the spectator experience.",
        "ru": "Управлял работой трибун в дни матчей, координировал презентационные активности до и во время матчей, решал организационные вопросы и обеспечивал комфорт зрителей."
      }
    },
    {
      "company": {
        "az": "Information and Communication Technologies Agency (ICTA)",
        "en": "Information and Communication Technologies Agency (ICTA)",
        "ru": "Information and Communication Technologies Agency (ICTA)"
      },
      "period": {
        "az": "09.2025 — 10.2025",
        "en": "Sep 2025 — Oct 2025",
        "ru": "09.2025 — 10.2025"
      },
      "role": {
        "az": "Analitika və məlumatların emalı üzrə təcrübəçi",
        "en": "Analytics and Data Processing Intern",
        "ru": "Стажёр по аналитике и обработке данных"
      },
      "desc": {
        "az": "Excel, SQL, Power BI və Python ilə məlumatların emalı və analizi; AI prompt engineering, veb-saytlardan avtomatlaşdırılmış məlumat çıxarılması, AI əsaslı verilənlər bazaları, veb tətbiqlər və avtonom AI agentləri üzrə praktiki iş.",
        "en": "Performed data processing and analysis using Excel, SQL, Power BI and Python. Worked on AI prompt engineering, automated web data extraction, AI-powered databases, web applications and autonomous AI agents.",
        "ru": "Обрабатывал и анализировал данные с помощью Excel, SQL, Power BI и Python. Работал с prompt engineering, автоматизированным извлечением веб-данных, базами данных и веб-приложениями на базе ИИ, автономными ИИ-агентами."
      }
    },
    {
      "company": {
        "az": "İ TİCKET — CIS Games 2025",
        "en": "İ TİCKET — CIS Games 2025",
        "ru": "İ TİCKET — Игры СНГ 2025"
      },
      "period": {
        "az": "09.2025 — 10.2025",
        "en": "Sep 2025 — Oct 2025",
        "ru": "09.2025 — 10.2025"
      },
      "role": {
        "az": "Məkan üzrə bilet əməliyyatları koordinatoru",
        "en": "Venue Ticketing Coordinator",
        "ru": "Координатор билетных операций на площадке"
      },
      "desc": {
        "az": "3-cü MDB Oyunlarında bilet satışına və kassalara nəzarət, gündəlik satış və maliyyə hesabatları, bilet yoxlanışı və könüllülərin koordinasiyası.",
        "en": "Managed venue ticket sales and cashier operations, prepared daily ticket sales and financial reports, coordinated ticket validation and supervised volunteers during the 3rd CIS Games.",
        "ru": "Управлял продажей билетов и работой касс, готовил ежедневные отчёты о продажах и финансовые отчёты, координировал проверку билетов и волонтёров на III Играх СНГ."
      }
    },
    {
      "company": {
        "az": "LEDAZ — Innovation Event MMC",
        "en": "LEDAZ — Innovation Event LLC",
        "ru": "LEDAZ — Innovation Event LLC"
      },
      "period": {
        "az": "09.2024 — 07.2025",
        "en": "Sep 2024 — Jul 2025",
        "ru": "09.2024 — 07.2025"
      },
      "role": {
        "az": "Tədbir layihə meneceri",
        "en": "Event Project Manager",
        "ru": "Менеджер event-проектов"
      },
      "desc": {
        "az": "Tədbirlərin konsepsiyadan icraya qədər idarə edilməsi, iş qrafikləri, büdcə, təchizatçı və podratçılar, qiymət təkliflərinin müqayisəsi, tender tələblərinin təhlili, kommersiya təklifləri və logistika.",
        "en": "Managed events from concept to execution, schedules, budgets, vendors and contractors; compared quotations, analyzed tender requirements, prepared commercial proposals and coordinated logistics.",
        "ru": "Управлял мероприятиями от концепции до реализации, графиками, бюджетами, поставщиками и подрядчиками; сравнивал ценовые предложения, анализировал тендерные требования, готовил коммерческие предложения и координировал логистику."
      }
    },
    {
      "company": {
        "az": "Veysəloğlu Group — Araz MMC",
        "en": "Veyseloglu Group — Araz LLC",
        "ru": "Veyseloglu Group — Araz LLC"
      },
      "period": {
        "az": "09.2023 — 08.2024",
        "en": "Sep 2023 — Aug 2024",
        "ru": "09.2023 — 08.2024"
      },
      "role": {
        "az": "Anbar və inventar uçotu üzrə mütəxəssis",
        "en": "Warehouse & Inventory Accounting Specialist",
        "ru": "Специалист по складскому учёту и учёту запасов"
      },
      "desc": {
        "az": "Maliyyə və kommersiya sənədləri, alış-satış əməliyyatları, anbar qalıqları, mal hərəkəti, inventarizasiya və üzləşdirmələr. Mikro, Logo və Tiger ERP sistemləri ilə iş.",
        "en": "Managed financial and commercial documentation, purchase and sales transactions, stock movements, inventory counts and reconciliations using Mikro, Logo and Tiger ERP systems.",
        "ru": "Вёл финансовую и коммерческую документацию, операции закупок и продаж, движение запасов, инвентаризацию и сверки в ERP-системах Mikro, Logo и Tiger."
      }
    },
    {
      "company": {
        "az": "Veysəloğlu Group — Khoncha MMC",
        "en": "Veyseloglu Group — Khoncha LLC",
        "ru": "Veyseloglu Group — Khoncha LLC"
      },
      "period": {
        "az": "03.2023 — 09.2023",
        "en": "Mar 2023 — Sep 2023",
        "ru": "03.2023 — 09.2023"
      },
      "role": {
        "az": "İnventar və istehsalat uçotu üzrə əməkdaş",
        "en": "Inventory & Production Accounting Clerk",
        "ru": "Сотрудник по учёту запасов и производства"
      },
      "desc": {
        "az": "Xammal və ümumi təchizat anbarlarının uçotu, alış sənədləri, Araz filiallarına mal transferləri, aylıq inventarizasiya, düzəlişlər və daxili satışlar.",
        "en": "Managed raw materials and general supplies inventory, purchase documents, transfers to Araz branches, month-end stock counts, adjustments and internal sales.",
        "ru": "Вёл учёт сырья и хозяйственных запасов, документы закупок, перемещения в филиалы Araz, ежемесячную инвентаризацию, корректировки и внутренние продажи."
      }
    },
    {
      "company": {
        "az": "Veysəloğlu Group — Khoncha MMC",
        "en": "Veyseloglu Group — Khoncha LLC",
        "ru": "Veyseloglu Group — Khoncha LLC"
      },
      "period": {
        "az": "10.2020 — 06.2021",
        "en": "Oct 2020 — Jun 2021",
        "ru": "10.2020 — 06.2021"
      },
      "role": {
        "az": "İnventar və istehsalat uçotu üzrə əməkdaş",
        "en": "Inventory & Production Accounting Clerk",
        "ru": "Сотрудник по учёту запасов и производства"
      },
      "desc": {
        "az": "Mikro proqramında ət anbarının uçotu, alışlar, xammalın hazır məhsula çevrilməsi, Araz filiallarına transferlər, aylıq silinmələr və anbar qalıqları.",
        "en": "Maintained meat warehouse records in Mikro, recorded purchases, raw material conversion into finished products, transfers to Araz branches, month-end write-offs and stock balances.",
        "ru": "Вёл учёт мясного склада в Mikro, закупок, переработки сырья в готовую продукцию, перемещений в филиалы Araz, ежемесячных списаний и остатков."
      }
    },
    {
      "company": {
        "az": "Azur Resort & Spa — Antalya · Əlavə portfolio təcrübəsi",
        "en": "Azur Resort & Spa — Antalya · Additional portfolio experience",
        "ru": "Azur Resort & Spa — Анталья · Дополнительный опыт из портфолио"
      },
      "period": {
        "az": "05.2019 — 03.2020",
        "en": "May 2019 — Mar 2020",
        "ru": "05.2019 — 03.2020"
      },
      "role": {
        "az": "DJ",
        "en": "DJ",
        "ru": "DJ"
      },
      "desc": {
        "az": "5 ulduzlu beynəlxalq oteldə əyləncə proqramlarının təşkili, canlı çıxışlar və tədbir koordinasiyası.",
        "en": "Entertainment programming, live performances and event coordination at a 5-star international resort.",
        "ru": "Развлекательные программы, живые выступления и координация мероприятий в 5-звездочном международном отеле."
      }
    },
    {
      "company": {
        "az": "iTicket — Formula 1 SOCAR Azerbaijan Grand Prix 2019",
        "en": "iTicket — Formula 1 SOCAR Azerbaijan Grand Prix 2019",
        "ru": "iTicket — Formula 1 SOCAR Azerbaijan Grand Prix 2019"
      },
      "period": {
        "az": "04.2019 — Frilans",
        "en": "Apr 2019 — Freelance",
        "ru": "04.2019 — Фриланс"
      },
      "role": {
        "az": "Bilet nəzarəti üzrə əməkdaş",
        "en": "Ticket Control Officer",
        "ru": "Сотрудник билетного контроля"
      },
      "desc": {
        "az": "Bilet yoxlanışı və giriş idarəetmə sistemlərinin operativ şəkildə icrası.",
        "en": "Operational execution of ticket control and access management systems.",
        "ru": "Оперативный контроль билетов и управление входными системами."
      }
    },
    {
      "company": {
        "az": "Throne Beach Resort & Spa — Antalya · Əlavə portfolio təcrübəsi",
        "en": "Throne Beach Resort & Spa — Antalya · Additional portfolio experience",
        "ru": "Throne Beach Resort & Spa — Анталья · Дополнительный опыт из портфолио"
      },
      "period": {
        "az": "04.2018 — 11.2018",
        "en": "Apr 2018 — Nov 2018",
        "ru": "04.2018 — 11.2018"
      },
      "role": {
        "az": "İdman animasiyası və DJ assistenti",
        "en": "Land Sport / DJ Assistant",
        "ru": "Ассистент DJ / спортивная анимация"
      },
      "desc": {
        "az": "Qonaqlar üçün animasiya proqramları, idman tədbirlərinin koordinasiyası və DJ fəaliyyətinə dəstək.",
        "en": "Guest animation programs, sports event coordination and DJ assistant duties.",
        "ru": "Анимационные программы для гостей, координация спортивных мероприятий и помощь DJ."
      }
    },
    {
      "company": {
        "az": "4-cü İslam Həmrəyliyi Oyunları",
        "en": "4th Islamic Solidarity Games",
        "ru": "4-е Игры исламской солидарности"
      },
      "period": {
        "az": "04.2017 — 07.2017",
        "en": "Apr 2017 — Jul 2017",
        "ru": "04.2017 — 07.2017"
      },
      "role": {
        "az": "Tamaşaçı xidmətləri üzrə supervayzer",
        "en": "Spectator Services Supervisor",
        "ru": "Супервайзер зрительских служб"
      },
      "desc": {
        "az": "Tamaşaçı xidmətləri komandasına rəhbərlik, prosedurların koordinasiyası və qonaq axınının idarə olunması.",
        "en": "Led spectator services team, coordinated procedures and managed guest flow.",
        "ru": "Руководство командой зрительского сервиса, координация процедур и управление потоком гостей."
      }
    }
  ],
  "skills": [
    [
      "Microsoft Excel",
      "Microsoft Excel",
      "Microsoft Excel",
      "Advanced"
    ],
    [
      "Power Query",
      "Power Query",
      "Power Query",
      ""
    ],
    [
      "Pivot cədvəllər və diaqramlar",
      "Pivot Tables & Charts",
      "Сводные таблицы и диаграммы",
      ""
    ],
    [
      "Məlumatların təmizlənməsi və yoxlanması",
      "Data Cleaning & Validation",
      "Очистка и проверка данных",
      ""
    ],
    [
      "Analiz, hesabat və dashboard",
      "Analysis, Reporting & Dashboards",
      "Анализ, отчёты и дашборды",
      ""
    ],
    [
      "SQL",
      "SQL",
      "SQL",
      "Foundational"
    ],
    [
      "AI Prompt Engineering",
      "AI Prompt Engineering",
      "AI Prompt Engineering",
      ""
    ],
    [
      "Power BI / Python",
      "Power BI / Python",
      "Power BI / Python",
      "Internship"
    ],
    [
      "Layihə və əməliyyat idarəetməsi",
      "Project & Operations Management",
      "Управление проектами и операциями",
      ""
    ],
    [
      "Büdcə və tender idarəetməsi",
      "Budget & Tender Management",
      "Управление бюджетами и тендерами",
      ""
    ],
    [
      "Mühasibat və maliyyə",
      "Accounting & Finance",
      "Бухгалтерия и финансы",
      ""
    ],
    [
      "MS Office paketi",
      "MS Office Suite",
      "MS Office Suite",
      ""
    ],
    [
      "Tədbir koordinasiyası",
      "Event Coordination",
      "Координация мероприятий",
      ""
    ],
    [
      "Maşın öyrənməsi",
      "Machine Learning",
      "Машинное обучение",
      "Portfolio"
    ]
  ],
  "soft": {
    "az": [
      "Liderlik",
      "Yaradıcılıq",
      "Analitik düşüncə",
      "Komanda işi",
      "Stressə davamlılıq",
      "Ünsiyyət",
      "Çoxtapşırıqlılıq",
      "Təchizatçıların idarə olunması",
      "Sahə əməliyyatları",
      "Strateji planlaşdırma",
      "Problemlərin həlli",
      "Kritik düşüncə",
      "Detallara diqqət",
      "Vaxtın idarə olunması",
      "Logistika"
    ],
    "en": [
      "Leadership",
      "Creativity",
      "Analytical thinking",
      "Teamwork",
      "Stress resilience",
      "Communication",
      "Multitasking",
      "Vendor management",
      "On-site operations",
      "Strategic planning",
      "Problem-solving",
      "Critical thinking",
      "Attention to detail",
      "Time management",
      "Logistics"
    ],
    "ru": [
      "Лидерство",
      "Креативность",
      "Аналитическое мышление",
      "Командная работа",
      "Стрессоустойчивость",
      "Коммуникация",
      "Многозадачность",
      "Управление подрядчиками",
      "Полевые операции",
      "Стратегическое планирование",
      "Решение проблем",
      "Критическое мышление",
      "Внимание к деталям",
      "Управление временем",
      "Логистика"
    ]
  },
  "education": [
    {
      "tag": "BBU",
      "title": {
        "az": "Bakı Biznes Universiteti",
        "en": "Baku Business University",
        "ru": "Бакинский бизнес-университет"
      },
      "desc": {
        "az": "Bakalavr — İnformasiya texnologiyaları · GPA 88.7",
        "en": "Bachelor’s degree — Information Technology · GPA 88.7",
        "ru": "Бакалавриат — информационные технологии · GPA 88.7"
      },
      "period": {
        "az": "2020 — 2026",
        "en": "2020 — 2026",
        "ru": "2020 — 2026"
      }
    },
    {
      "tag": "AMEA",
      "title": {
        "az": "Azərbaycan Milli Elmlər Akademiyası",
        "en": "Azerbaijan National Academy of Sciences",
        "ru": "Национальная академия наук Азербайджана"
      },
      "desc": {
        "az": "Bakalavr — Kompüter və informasiya elmləri və dəstək xidmətləri",
        "en": "Bachelor’s degree — Computer and Information Sciences and Support Services",
        "ru": "Бакалавриат — компьютерные и информационные науки и службы поддержки"
      },
      "period": {
        "az": "2024 — 2025",
        "en": "2024 — 2025",
        "ru": "2024 — 2025"
      }
    },
    {
      "tag": "BİTK",
      "title": {
        "az": "Bakı İdarəetmə və Texnologiya Kolleci",
        "en": "Baku Management and Technology College",
        "ru": "Бакинский колледж управления и технологий"
      },
      "desc": {
        "az": "Subbakalavr — İnformasiya texnologiyaları · GPA 95.4",
        "en": "Sub-Bachelor’s degree — Information Technology · GPA 95.4",
        "ru": "Среднее специальное образование — информационные технологии · GPA 95.4"
      },
      "period": {
        "az": "2013 — 2017",
        "en": "2013 — 2017",
        "ru": "2013 — 2017"
      }
    },
    {
      "tag": "AZ",
      "title": {
        "az": "Azərbaycan dili",
        "en": "Azerbaijani language",
        "ru": "Азербайджанский язык"
      },
      "desc": {
        "az": "Ana dili",
        "en": "Native language",
        "ru": "Родной язык"
      },
      "period": {
        "az": "Dil",
        "en": "Language",
        "ru": "Язык"
      }
    },
    {
      "tag": "EN/RU",
      "title": {
        "az": "İngilis və rus dilləri",
        "en": "English and Russian languages",
        "ru": "Английский и русский языки"
      },
      "desc": {
        "az": "B1 səviyyəsi",
        "en": "B1 level",
        "ru": "Уровень B1"
      },
      "period": {
        "az": "Dillər",
        "en": "Languages",
        "ru": "Языки"
      }
    },
    {
      "tag": "HX",
      "title": {
        "az": "Hərbi xidmət",
        "en": "Military service",
        "ru": "Военная служба"
      },
      "desc": {
        "az": "Tamamlanıb",
        "en": "Completed",
        "ru": "Завершена"
      },
      "period": {
        "az": "2021 — 2023",
        "en": "2021 — 2023",
        "ru": "2021 — 2023"
      }
    },
    {
      "tag": "TR",
      "title": {
        "az": "Türk dili",
        "en": "Turkish language",
        "ru": "Турецкий язык"
      },
      "desc": {
        "az": "C2",
        "en": "C2",
        "ru": "C2"
      },
      "period": {
        "az": "Dil",
        "en": "Language",
        "ru": "Язык"
      }
    },
    {
      "tag": "B/C",
      "title": {
        "az": "Sürücülük vəsiqəsi",
        "en": "Driving license",
        "ru": "Водительское удостоверение"
      },
      "desc": {
        "az": "B/C",
        "en": "B/C",
        "ru": "B/C"
      },
      "period": {
        "az": "Kateqoriya",
        "en": "Category",
        "ru": "Категория"
      }
    }
  ],
  "certs": [
    [
      {
        "az": "HackerRank",
        "en": "HackerRank",
        "ru": "HackerRank"
      },
      {
        "az": "JavaScript — orta səviyyə",
        "en": "JavaScript (Intermediate)",
        "ru": "JavaScript — средний уровень"
      },
      "24 Feb 2026 · ID: 3CF1FC6C849C",
      "hackerrank training"
    ],
    [
      {
        "az": "HackerRank",
        "en": "HackerRank",
        "ru": "HackerRank"
      },
      {
        "az": "SQL — baza səviyyəsi",
        "en": "SQL (Basic)",
        "ru": "SQL — базовый уровень"
      },
      "23 Feb 2026",
      "hackerrank training"
    ],
    [
      {
        "az": "HackerRank",
        "en": "HackerRank",
        "ru": "HackerRank"
      },
      {
        "az": "JavaScript — baza səviyyəsi",
        "en": "JavaScript (Basic)",
        "ru": "JavaScript — базовый уровень"
      },
      "2026",
      "hackerrank training"
    ],
    [
      {
        "az": "HackerRank",
        "en": "HackerRank",
        "ru": "HackerRank"
      },
      {
        "az": "CSS — baza səviyyəsi",
        "en": "CSS (Basic)",
        "ru": "CSS — базовый уровень"
      },
      "2026",
      "hackerrank training"
    ],
    [
      {
        "az": "HackerRank",
        "en": "HackerRank",
        "ru": "HackerRank"
      },
      {
        "az": "Problem həlli",
        "en": "Problem Solving",
        "ru": "Решение задач"
      },
      "2026",
      "hackerrank training"
    ],
    [
      {
        "az": "HackerRank",
        "en": "HackerRank",
        "ru": "HackerRank"
      },
      {
        "az": "Python / texniki bacarıqlar",
        "en": "Python / Technical Skills",
        "ru": "Python / технические навыки"
      },
      "2026",
      "hackerrank training"
    ],
    [
      {
        "az": "UEFA EURO 2016",
        "en": "UEFA EURO 2016",
        "ru": "UEFA EURO 2016"
      },
      {
        "az": "Azərbaycan–Xorvatiya matçında könüllü fəaliyyət",
        "en": "Volunteer work at the Azerbaijan–Croatia match",
        "ru": "Волонтерская деятельность на матче Азербайджан — Хорватия"
      },
      "2015",
      "volunteer sport"
    ],
    [
      {
        "az": "UEFA EURO 2016",
        "en": "UEFA EURO 2016",
        "ru": "UEFA EURO 2016"
      },
      {
        "az": "Azərbaycan–İtaliya matçında könüllü fəaliyyət",
        "en": "Volunteer work at the Azerbaijan–Italy match",
        "ru": "Волонтерская деятельность на матче Азербайджан — Италия"
      },
      "2015",
      "volunteer sport"
    ],
    [
      {
        "az": "42-ci Bakı Dünya Şahmat Olimpiadası",
        "en": "42nd Chess Olympiad Baku",
        "ru": "42-я Всемирная шахматная олимпиада в Баку"
      },
      {
        "az": "Dəyərli töhfəyə görə sertifikat",
        "en": "Certificate for valuable contribution",
        "ru": "Сертификат за ценный вклад"
      },
      "2016",
      "volunteer award sport"
    ],
    [
      {
        "az": "4-cü İslam Həmrəyliyi Oyunları",
        "en": "4th Islamic Solidarity Games",
        "ru": "4-е Игры исламской солидарности"
      },
      {
        "az": "“Focus on Solidarity” müsabiqəsində 3-cü yer",
        "en": "3rd place in the “Focus on Solidarity” competition",
        "ru": "3-е место в конкурсе «Focus on Solidarity»"
      },
      "2017",
      "award sport"
    ],
    [
      {
        "az": "UEFA U-17 Avropa Çempionatı",
        "en": "UEFA U-17 European Championship",
        "ru": "Чемпионат Европы UEFA U-17"
      },
      {
        "az": "IT şöbəsində könüllü fəaliyyət",
        "en": "Volunteer work in the IT department",
        "ru": "Волонтерская деятельность в IT-отделе"
      },
      "2016",
      "volunteer sport"
    ],
    [
      {
        "az": "Sosial media layihəsi",
        "en": "Social Media Project",
        "ru": "Проект по социальным сетям"
      },
      {
        "az": "Sosial şəbəkələrdən düzgün istifadə layihəsində iştirak",
        "en": "Participation in a project on proper social media use",
        "ru": "Участие в проекте о правильном использовании социальных сетей"
      },
      "2016",
      "training"
    ],
    [
      {
        "az": "Red Bull Soapbox Race Bakı",
        "en": "Red Bull Soapbox Race Baku",
        "ru": "Red Bull Soapbox Race Баку"
      },
      {
        "az": "Tədbirin uğuruna töhfəyə görə",
        "en": "For contribution to the success of the event",
        "ru": "За вклад в успех мероприятия"
      },
      "2016",
      "volunteer award"
    ],
    [
      {
        "az": "Baku 2015 Avropa Oyunları",
        "en": "Baku 2015 European Games",
        "ru": "Европейские игры Баку 2015"
      },
      {
        "az": "Flamekeeper proqramını tamamlama sertifikatı",
        "en": "Flamekeeper completion certificate",
        "ru": "Сертификат о завершении программы Flamekeeper"
      },
      "2015",
      "volunteer sport"
    ],
    [
      {
        "az": "Baku 2015 Avropa Oyunları",
        "en": "Baku 2015 European Games",
        "ru": "Европейские игры Баку 2015"
      },
      {
        "az": "Flamekeeper vəzifəsinin icrası",
        "en": "Performance of Flamekeeper duties",
        "ru": "Выполнение обязанностей Flamekeeper"
      },
      "2015",
      "volunteer sport"
    ],
    [
      {
        "az": "Startup School — Qarabağ",
        "en": "Startup School — Karabakh",
        "ru": "Startup School — Карабах"
      },
      {
        "az": "Təlim və mentorluq proqramı",
        "en": "Training and mentoring program",
        "ru": "Программа обучения и менторства"
      },
      "2020",
      "training"
    ],
    [
      {
        "az": "4-cü İslam Həmrəyliyi Oyunları",
        "en": "4th Islamic Solidarity Games",
        "ru": "4-е Игры исламской солидарности"
      },
      {
        "az": "Bədən dili üzrə könüllü inkişaf proqramı",
        "en": "Volunteer development program on body language",
        "ru": "Программа развития волонтеров по языку тела"
      },
      "2017",
      "training volunteer"
    ],
    [
      {
        "az": "4-cü İslam Həmrəyliyi Oyunları",
        "en": "4th Islamic Solidarity Games",
        "ru": "4-е Игры исламской солидарности"
      },
      {
        "az": "Uğurlu karyera üzrə könüllü inkişaf proqramı",
        "en": "Volunteer development program on building a successful career",
        "ru": "Программа развития волонтеров по успешной карьере"
      },
      "2017",
      "training volunteer"
    ],
    [
      {
        "az": "4-cü İslam Həmrəyliyi Oyunları",
        "en": "4th Islamic Solidarity Games",
        "ru": "4-е Игры исламской солидарности"
      },
      {
        "az": "Özünü kəşf et könüllü inkişaf proqramı",
        "en": "“Discover Yourself” volunteer development program",
        "ru": "Программа развития волонтеров «Познай себя»"
      },
      "2017",
      "training volunteer"
    ],
    [
      {
        "az": "Baku 2015",
        "en": "Baku 2015",
        "ru": "Баку 2015"
      },
      {
        "az": "Gənclərin Turizm Forumunda iştirak",
        "en": "Participation in the Youth Tourism Forum",
        "ru": "Участие в молодежном туристическом форуме"
      },
      "2015",
      "training volunteer"
    ],
    [
      {
        "az": "AR Gənclər və İdman Nazirliyi",
        "en": "Ministry of Youth and Sports of Azerbaijan",
        "ru": "Министерство молодежи и спорта Азербайджана"
      },
      {
        "az": "Qış kuboku basketbol turnirində 3-cü yer",
        "en": "3rd place in the Winter Cup basketball tournament",
        "ru": "3-е место в баскетбольном турнире «Зимний кубок»"
      },
      "2013",
      "sport award"
    ],
    [
      {
        "az": "Soyuq Əllər, İsti Ürək",
        "en": "Cold Hands, Warm Heart",
        "ru": "Холодные руки, теплое сердце"
      },
      {
        "az": "Mələklər xeyriyyə yarmarkasında komanda rəhbəri",
        "en": "Team leader at the Angels charity fair",
        "ru": "Руководитель команды на благотворительной ярмарке Angels"
      },
      "2016",
      "volunteer award"
    ],
    [
      {
        "az": "Formula 1 Grand Prix of Europe",
        "en": "Formula 1 Grand Prix of Europe",
        "ru": "Formula 1 Grand Prix of Europe"
      },
      {
        "az": "Aktiv fəaliyyətə görə",
        "en": "For active contribution",
        "ru": "За активную деятельность"
      },
      "2016",
      "volunteer sport"
    ],
    [
      {
        "az": "Formula 1 Grand Prix of Europe",
        "en": "Formula 1 Grand Prix of Europe",
        "ru": "Formula 1 Grand Prix of Europe"
      },
      {
        "az": "Könüllü iştirak sertifikatı",
        "en": "Volunteer participation certificate",
        "ru": "Сертификат волонтерского участия"
      },
      "2016",
      "volunteer sport"
    ],
    [
      {
        "az": "Banc Tourism",
        "en": "Banc Tourism",
        "ru": "Banc Tourism"
      },
      {
        "az": "Turizm bələdçilərinin formalaşdırılması layihəsi",
        "en": "Tour guide development project",
        "ru": "Проект подготовки туристических гидов"
      },
      "2017",
      "training"
    ],
    [
      {
        "az": "IT kursu",
        "en": "IT Course",
        "ru": "IT-курс"
      },
      {
        "az": "Veb sistemləri, MS Office paketi və kompüter qrafikası",
        "en": "Web systems, MS Office Suite and computer graphics",
        "ru": "Веб-системы, пакет MS Office и компьютерная графика"
      },
      "2017",
      "training"
    ],
    [
      {
        "az": "Təşəkkür sertifikatı",
        "en": "Certificate of Thanks",
        "ru": "Благодарственный сертификат"
      },
      {
        "az": "Beynəlxalq və yerli tədbirlərdə davamlı iştiraka görə",
        "en": "For continuous participation in international and local events",
        "ru": "За постоянное участие в международных и местных мероприятиях"
      },
      "2015–2026",
      "award volunteer"
    ]
  ]
};
const projects = [
  {
    "title": "CVYarat Online",
    "url": "https://www.cvyarat.online/",
    "kind": {
      "az": "IT / Web platforma",
      "en": "IT / Web platform",
      "ru": "IT / веб-платформа"
    },
    "desc": {
      "az": "93 CV şablonu, canlı redaktor və önizləmə, ATS uyğun formatlar, A4 PDF ixracı, avtomatik yadda saxlama və AZ/EN/RU dil dəstəyi olan CV yaratma platforması.",
      "en": "Online CV builder with 93 templates, live editing and preview, ATS-friendly formats, A4 PDF export, autosave and AZ/EN/RU support.",
      "ru": "Конструктор резюме с 93 шаблонами, редактором и предпросмотром, ATS-совместимыми форматами, экспортом PDF A4, автосохранением и поддержкой AZ/EN/RU."
    },
    "tags": [
      "Web",
      "CV Builder",
      "Product UI"
    ]
  },
  {
    "title": "Lingo",
    "url": "https://lingo-9tn.pages.dev/",
    "kind": {
      "az": "AI / Dil öyrənmə platforması",
      "en": "AI / Language learning platform",
      "ru": "ИИ / Платформа изучения языков"
    },
    "desc": {
      "az": "İngilis və rus dilləri üçün fərdiləşdirilmiş planlar, AI mentor, interaktiv tapşırıqlar, irəliləyiş izləmə və A1–C2 CEFR səviyyələri.",
      "en": "English and Russian learning platform with personalized plans, AI mentor, interactive exercises, progress tracking and CEFR A1–C2 levels.",
      "ru": "Платформа изучения английского и русского языков с персональными планами, ИИ-наставником, интерактивными заданиями, отслеживанием прогресса и уровнями CEFR A1–C2."
    },
    "tags": [
      "AI",
      "Education",
      "Web",
      "CEFR"
    ]
  },
  {
    "title": "MagistrAI",
    "url": "https://magistrai.pages.dev/",
    "kind": {
      "az": "IT / AI yönümlü platforma",
      "en": "IT / AI-oriented platform",
      "ru": "IT / AI-ориентированная платформа"
    },
    "desc": {
      "az": "Magistratura ixtisaslarının qəbul balı və seçimlərə əsasən sıralanması, risk səviyyələrinin müqayisəsi və PDF seçim siyahısı. Verilənlər bazası Excel-də sıfırdan qurulub SQL-ə köçürülüb; Gemini API inteqrasiya edilib.",
      "en": "Prototype ranking master’s programs by admission scores and preferences, comparing risk levels and generating a PDF selection list. Built the database from scratch in Excel, migrated it to SQL and integrated the Gemini API.",
      "ru": "Прототип подбора магистерских программ по баллам и предпочтениям, сравнения рисков и формирования PDF-списка. База создана с нуля в Excel, перенесена в SQL; интегрирован Gemini API."
    },
    "tags": [
      "AI",
      "Web",
      "Education",
      "Excel",
      "SQL",
      "Gemini API"
    ]
  },
  {
    "title": "MagistrPlus",
    "url": "https://magistrplus.pages.dev/",
    "kind": {
      "az": "IT / Təhsil platforması",
      "en": "IT / Education platform",
      "ru": "IT / образовательная платформа"
    },
    "desc": {
      "az": "Təhsil yönümlü web platforma. Son IT layihələri sırasında istifadəçi interfeysi və platforma təqdimatı üzrə iş kimi əlavə olunub.",
      "en": "An education-oriented web platform, added among the latest IT projects as work focused on user interface and platform presentation.",
      "ru": "Образовательная веб-платформа, добавленная среди последних IT-проектов как работа с фокусом на интерфейс и презентацию платформы."
    },
    "tags": [
      "Education",
      "Web",
      "Platform"
    ]
  }
];
const ui = {
  "az": {
    "meta_description": "Rasim Abdullayev — IT yönümlü portfolio və CV. Təcrübə, IT layihələri, bacarıqlar, sertifikatlar, təhsil və motivasiya məktubu.",
    "brand_role": "Data Analytics · AI · Web Systems",
    "nav_exp": "Təcrübə",
    "nav_projects": "IT Layihələr",
    "nav_skills": "Bacarıqlar",
    "nav_edu": "Təhsil",
    "nav_certs": "Sertifikatlar",
    "nav_motivation": "Motivasiya",
    "nav_contact": "Əlaqə",
    "hero_eyebrow": "IT Portfolio · Analytics · Web Systems",
    "hero_title": "Rasim Abdullayev",
    "hero_subtitle": "Junior Data Analyst | AI Prompt Engineering | AI əsaslı layihələrin hazırlanması | Süni intellekt",
    "hero_desc": "Layihə və əməliyyat idarəetməsi, inventar uçotu və məlumatların emalı təcrübəsini qabaqcıl Excel, baza SQL və AI bacarıqları ilə birləşdirərək data analitikası istiqamətində inkişaf edirəm.",
    "hero_cta1": "Layihələrə bax",
    "hero_cta2": "CV kimi çap et",
    "hero_cta3": "Əlaqə yarat",
    "status": "Junior Data Analyst",
    "available": "Junior Data Analyst imkanlarına açıq",
    "stat_exp": "İş təcrübəsi qeydi",
    "stat_projects": "Son IT layihə",
    "stat_certs": "Sertifikat və nailiyyət",
    "terminal_title": "portfolio.system",
    "terminal_1": "status: IT transition active",
    "terminal_2": "focus: analytics + data processing",
    "terminal_3": "projects: CVYarat, Lingo, MagistrAI, MagistrPlus",
    "terminal_4": "mode: GitHub Pages ready",
    "sec_exp_label": "Karyera yolu",
    "sec_exp_title": "Təcrübə",
    "sec_exp_copy": "CV-dəki iş təcrübələri və əvvəlki portfoliodan saxlanılan əlavə təcrübələr.",
    "sec_projects_label": "Son işlər",
    "sec_projects_title": "IT layihələr",
    "sec_projects_copy": "CV-dəki layihələr və əvvəlki portfoliodan saxlanılan MagistrPlus.",
    "open_project": "Canlı layihəyə keç",
    "project_note": "Created project",
    "sec_skills_label": "Bacarıqlar",
    "sec_skills_title": "Peşəkar bacarıqlar",
    "sec_skills_copy": "Texniki və peşəkar bacarıqlar; səviyyələr yalnız məlum olduqda göstərilir.",
    "soft_label": "Güclü tərəflər",
    "sec_edu_label": "Təhsil",
    "sec_edu_title": "Təhsil və dillər",
    "sec_edu_copy": "Təhsil, dil bilikləri və hərbi xidmət məlumatları.",
    "sec_cert_label": "Sertifikatlar",
    "sec_cert_title": "Sertifikatlar və mükafatlar",
    "sec_cert_copy": "Texniki bacarıqlar, könüllülük, idman və beynəlxalq tədbirlər üzrə bütün sertifikatlar.",
    "search_placeholder": "Sertifikat axtar...",
    "filter_all": "Hamısı",
    "filter_hackerrank": "HackerRank",
    "filter_sport": "İdman",
    "filter_volunteer": "Könüllülük",
    "filter_training": "Təlim",
    "filter_award": "Mükafat",
    "sec_motivation_label": "Motivasiya məktubu",
    "sec_motivation_title": "Data analitikası sahəsində karyera məqsədim",
    "sec_motivation_copy": "Portfolio daxilində təqdim oluna bilən qısa professional motivasiya məktubu.",
    "copy_letter": "Məktubu kopyala",
    "copied": "Kopyalandı",
    "letter": [
      "Hörmətli işəgötürən,",
      "Junior Data Analyst vəzifəsində karyeramı inkişaf etdirmək üçün müraciət edirəm. İnformasiya texnologiyaları üzrə təhsilim, layihə və əməliyyat idarəetməsi, anbar və inventar uçotu sahələrində təcrübəm məlumatlarla işləmək və biznes proseslərini anlamaq üçün möhkəm baza yaradıb.",
      "ICTA-da analitika və məlumatların emalı üzrə təcrübə proqramında Excel, SQL, Power BI və Python ilə praktiki tapşırıqlar yerinə yetirmişəm. Microsoft Excel üzrə qabaqcıl biliklərimə Power Query, Pivot cədvəllər, məlumatların təmizlənməsi və dashboard hazırlanması daxildir. SQL üzrə baza biliklərimi inkişaf etdirirəm. MagistrAI layihəsində verilənlər bazasını Excel-də sıfırdan quraraq SQL-ə köçürmüş və Gemini API inteqrasiyası üzərində çalışmışam.",
      "LEDAZ-da layihə meneceri kimi büdcə, tender, qiymət təklifləri və logistika ilə işləmişəm. Veysəloğlu şirkətlər qrupunda inventar uçotu, ERP sistemləri və məlumatların dəqiqliyi üzrə təcrübə qazanmışam. Beynəlxalq idman tədbirlərində isə əməliyyat koordinasiyası və MDB Oyunlarında gündəlik satış və maliyyə hesabatlarının hazırlanması ilə məşğul olmuşam.",
      "Məqsədim bu təcrübəni analitik bacarıqlarımla birləşdirərək məlumatları biznes qərarlarını dəstəkləyən nəticələrə çevirməkdir. Komandanıza məsuliyyətli yanaşma, analitik düşüncə və davamlı öyrənmə istəyi ilə töhfə verməyə hazıram.",
      "Hörmətlə, Rasim Abdullayev"
    ],
    "sec_contact_label": "Əlaqə",
    "sec_contact_title": "Əlaqə məlumatları",
    "sec_contact_copy": "Mövcud CV-də olan əlaqə məlumatları saxlanılıb.",
    "phone": "Telefon",
    "email": "E-poçt",
    "location": "Məkan",
    "send_mail": "Məktub göndər",
    "whatsapp": "WhatsApp",
    "top": "Yuxarı",
    "rights": "Bütün hüquqlar qorunur."
  },
  "en": {
    "meta_description": "Rasim Abdullayev — IT-oriented portfolio and CV. Experience, IT projects, skills, certificates, education and motivation letter.",
    "brand_role": "Data Analytics · AI · Web Systems",
    "nav_exp": "Experience",
    "nav_projects": "IT Projects",
    "nav_skills": "Skills",
    "nav_edu": "Education",
    "nav_certs": "Certificates",
    "nav_motivation": "Motivation",
    "nav_contact": "Contact",
    "hero_eyebrow": "IT Portfolio · Analytics · Web Systems",
    "hero_title": "Rasim Abdullayev",
    "hero_subtitle": "Junior Data Analyst | AI Prompt Engineering | AI-Powered Project Development | Artificial Intelligence",
    "hero_desc": "Transitioning into data analytics with a background in project and operations management, inventory accounting and data processing, advanced Excel skills, foundational SQL and practical AI experience.",
    "hero_cta1": "View projects",
    "hero_cta2": "Print CV",
    "hero_cta3": "Contact",
    "status": "Junior Data Analyst",
    "available": "Open to Junior Data Analyst opportunities",
    "stat_exp": "Work experience entries",
    "stat_projects": "Latest IT projects",
    "stat_certs": "Certificates & achievements",
    "terminal_title": "portfolio.system",
    "terminal_1": "status: IT transition active",
    "terminal_2": "focus: analytics + data processing",
    "terminal_3": "projects: CVYarat, Lingo, MagistrAI, MagistrPlus",
    "terminal_4": "mode: GitHub Pages ready",
    "sec_exp_label": "Career path",
    "sec_exp_title": "Experience",
    "sec_exp_copy": "CV-aligned work history and additional experience retained from the previous portfolio.",
    "sec_projects_label": "Latest work",
    "sec_projects_title": "IT projects",
    "sec_projects_copy": "CV projects and MagistrPlus retained from the previous portfolio.",
    "open_project": "Open live project",
    "project_note": "Created project",
    "sec_skills_label": "Skills",
    "sec_skills_title": "Professional skills",
    "sec_skills_copy": "Technical and professional skills; proficiency levels shown where supported.",
    "soft_label": "Core strengths",
    "sec_edu_label": "Education",
    "sec_edu_title": "Education & languages",
    "sec_edu_copy": "Education, language skills and military service information.",
    "sec_cert_label": "Certificates",
    "sec_cert_title": "Certificates & awards",
    "sec_cert_copy": "All certificates across technical skills, volunteering, sports and international events.",
    "search_placeholder": "Search certificates...",
    "filter_all": "All",
    "filter_hackerrank": "HackerRank",
    "filter_sport": "Sports",
    "filter_volunteer": "Volunteering",
    "filter_training": "Training",
    "filter_award": "Awards",
    "sec_motivation_label": "Motivation letter",
    "sec_motivation_title": "My career goal in data analytics",
    "sec_motivation_copy": "A short professional motivation letter included inside the portfolio.",
    "copy_letter": "Copy letter",
    "copied": "Copied",
    "letter": [
      "Dear Hiring Manager,",
      "I am seeking a Junior Data Analyst position where I can build on my Information Technology education and professional background in project management, operations and inventory accounting. These roles have given me a practical understanding of business processes and the importance of accurate data.",
      "During my analytics and data processing internship at ICTA, I completed practical tasks using Excel, SQL, Power BI and Python. My advanced Excel skills include Power Query, Pivot Tables, data cleaning and dashboard development, and I continue to develop my foundational SQL knowledge. For MagistrAI, I built a database from scratch in Excel, migrated it to SQL and worked on integrating the Gemini API.",
      "As an Event Project Manager at LEDAZ, I worked with budgets, tenders, quotations and logistics. At Veyseloglu Group, I gained experience in inventory accounting, ERP systems and data accuracy. My international sporting event roles strengthened my operational coordination skills, including preparing daily ticket sales and financial reports at the CIS Games.",
      "My goal is to combine this business experience with analytical skills to turn data into actionable insights that support informed decisions. I am ready to contribute through analytical thinking, attention to detail, responsibility and a commitment to continuous learning.",
      "Sincerely, Rasim Abdullayev"
    ],
    "sec_contact_label": "Contact",
    "sec_contact_title": "Contact information",
    "sec_contact_copy": "The contact information from the existing CV is preserved.",
    "phone": "Phone",
    "email": "Email",
    "location": "Location",
    "send_mail": "Send email",
    "whatsapp": "WhatsApp",
    "top": "Top",
    "rights": "All rights reserved."
  },
  "ru": {
    "meta_description": "Rasim Abdullayev — IT-портфолио и CV. Опыт, IT-проекты, навыки, сертификаты, образование и мотивационное письмо.",
    "brand_role": "Data Analytics · AI · Web Systems",
    "nav_exp": "Опыт",
    "nav_projects": "IT-проекты",
    "nav_skills": "Навыки",
    "nav_edu": "Образование",
    "nav_certs": "Сертификаты",
    "nav_motivation": "Мотивация",
    "nav_contact": "Контакты",
    "hero_eyebrow": "IT Portfolio · Analytics · Web Systems",
    "hero_title": "Rasim Abdullayev",
    "hero_subtitle": "Junior Data Analyst | Prompt Engineering | Разработка ИИ-проектов | Искусственный интеллект",
    "hero_desc": "Развиваюсь в аналитике данных, сочетая опыт управления проектами и операциями, учёта запасов и обработки данных с продвинутым Excel, базовым SQL и практикой ИИ.",
    "hero_cta1": "Смотреть проекты",
    "hero_cta2": "Печать CV",
    "hero_cta3": "Связаться",
    "status": "Junior Data Analyst",
    "available": "Открыт к позициям Junior Data Analyst",
    "stat_exp": "Позиций в опыте работы",
    "stat_projects": "Последние IT-проекты",
    "stat_certs": "Сертификаты и достижения",
    "terminal_title": "portfolio.system",
    "terminal_1": "status: IT transition active",
    "terminal_2": "focus: analytics + data processing",
    "terminal_3": "projects: CVYarat, Lingo, MagistrAI, MagistrPlus",
    "terminal_4": "mode: GitHub Pages ready",
    "sec_exp_label": "Карьерный путь",
    "sec_exp_title": "Опыт",
    "sec_exp_copy": "Опыт работы по CV и дополнительные позиции из прежнего портфолио.",
    "sec_projects_label": "Последние работы",
    "sec_projects_title": "IT-проекты",
    "sec_projects_copy": "Проекты из CV и MagistrPlus из прежнего портфолио.",
    "open_project": "Открыть проект",
    "project_note": "Созданный проект",
    "sec_skills_label": "Навыки",
    "sec_skills_title": "Профессиональные навыки",
    "sec_skills_copy": "Технические и профессиональные навыки; уровни указаны при наличии данных.",
    "soft_label": "Сильные стороны",
    "sec_edu_label": "Образование",
    "sec_edu_title": "Образование и языки",
    "sec_edu_copy": "Информация об образовании, языках и военной службе.",
    "sec_cert_label": "Сертификаты",
    "sec_cert_title": "Сертификаты и награды",
    "sec_cert_copy": "Все сертификаты по техническим навыкам, волонтерству, спорту и международным мероприятиям.",
    "search_placeholder": "Поиск сертификатов...",
    "filter_all": "Все",
    "filter_hackerrank": "HackerRank",
    "filter_sport": "Спорт",
    "filter_volunteer": "Волонтерство",
    "filter_training": "Тренинг",
    "filter_award": "Награды",
    "sec_motivation_label": "Мотивационное письмо",
    "sec_motivation_title": "Моя карьерная цель в аналитике данных",
    "sec_motivation_copy": "Короткое профессиональное мотивационное письмо внутри портфолио.",
    "copy_letter": "Скопировать письмо",
    "copied": "Скопировано",
    "letter": [
      "Уважаемый работодатель,",
      "Я заинтересован в позиции Junior Data Analyst, на которой смогу применить образование в области информационных технологий и опыт управления проектами, операциями и учёта запасов. Этот опыт сформировал понимание бизнес-процессов и важности точности данных.",
      "Во время стажировки по аналитике и обработке данных в ICTA я выполнял практические задачи с Excel, SQL, Power BI и Python. Мои продвинутые навыки Excel включают Power Query, сводные таблицы, очистку данных и создание дашбордов. Продолжаю развивать базовые знания SQL. В проекте MagistrAI я создал базу данных с нуля в Excel, перенёс её в SQL и работал над интеграцией Gemini API.",
      "В LEDAZ я работал с бюджетами, тендерами, ценовыми предложениями и логистикой. В группе компаний Veyseloglu получил опыт учёта запасов, работы с ERP-системами и обеспечения точности данных. На международных спортивных мероприятиях занимался операционной координацией, а на Играх СНГ также готовил ежедневные отчёты о продажах билетов и финансовые отчёты.",
      "Моя цель — объединить бизнес-опыт с аналитическими навыками, превращая данные в полезные выводы для принятия решений. Готов внести вклад в работу команды благодаря аналитическому мышлению, вниманию к деталям, ответственности и стремлению к постоянному обучению.",
      "С уважением, Rasim Abdullayev"
    ],
    "sec_contact_label": "Контакты",
    "sec_contact_title": "Контактная информация",
    "sec_contact_copy": "Контактная информация из существующего CV сохранена.",
    "phone": "Телефон",
    "email": "Email",
    "location": "Локация",
    "send_mail": "Отправить письмо",
    "whatsapp": "WhatsApp",
    "top": "Наверх",
    "rights": "Все права защищены."
  }
};

const contact = {
  phone: "+994 55 676 01 15",
  phoneHref: "tel:+994556760115",
  whatsappHref: "https://wa.me/994556760115?text=" + encodeURIComponent("Salam Rasim bəy, CV-nizi gördüm və sizinlə əlaqə saxlamaq istəyirəm."),
  email: "rasimabdullayev6@gmail.com",
  emailHref: "mailto:rasimabdullayev6@gmail.com",
  linkedin: "linkedin.com/in/rasimabdullayev1997",
  linkedinHref: "https://www.linkedin.com/in/rasimabdullayev1997/",
  facebook: "facebook.com/rasimabdullayevofficial",
  facebookHref: "https://www.facebook.com/rasimabdullayevofficial",
  location: { az: "Bakı, Azərbaycan", en: "Baku, Azerbaijan", ru: "Баку, Азербайджан" }
};

const state = {
  lang: localStorage.getItem("portfolio-language") || "az",
  filter: "all",
  query: ""
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = (value) => String(value ?? "").replace(/[&<>'"]/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[char]));
const tr = (key) => ui[state.lang]?.[key] ?? ui.az[key] ?? key;
const pick = (obj) => obj?.[state.lang] ?? obj?.az ?? obj?.en ?? obj ?? "";

function setText() {
  document.documentElement.lang = state.lang;
  document.title = `Rasim Abdullayev — ${tr("brand_role")}`;
  const meta = $("#metaDescription");
  if (meta) meta.content = tr("meta_description");
  $$('[data-ui]').forEach(el => { el.textContent = tr(el.dataset.ui); });
  $("#certSearch").placeholder = tr("search_placeholder");
  $$(".lang-btn").forEach(btn => btn.classList.toggle("active", btn.dataset.lang === state.lang));
}

function renderStats() {
  const stats = [
    [profile.experiences.length, tr("stat_exp")],
    [projects.length, tr("stat_projects")],
    [profile.certs.length, tr("stat_certs")]
  ];
  $("#stats").innerHTML = stats.map(([n, label]) => `<div class="stat"><strong>${esc(n)}</strong><span>${esc(label)}</span></div>`).join("");
}

function renderExperiences() {
  $("#experienceList").innerHTML = profile.experiences.map(item => `
    <article class="experience-card reveal">
      <div class="period">${esc(pick(item.period))}</div>
      <div>
        <h3 class="role">${esc(pick(item.role))}</h3>
        <div class="company">${esc(pick(item.company))}</div>
        <p class="desc">${esc(pick(item.desc))}</p>
      </div>
    </article>`).join("");
}

function renderProjects() {
  $("#projectGrid").innerHTML = projects.map(project => `
    <article class="project-card reveal">
      <span class="kind">${esc(pick(project.kind))}</span>
      <h3>${esc(project.title)}</h3>
      <p>${esc(pick(project.desc))}</p>
      <div class="tag-row">${project.tags.map(tag => `<span class="tag">${esc(tag)}</span>`).join("")}</div>
      <a href="${esc(project.url)}" target="_blank" rel="noreferrer">${esc(tr("open_project"))} →</a>
    </article>`).join("");
}

function renderSkills() {
  const index = { az: 0, en: 1, ru: 2 }[state.lang] ?? 0;
  $("#skillGrid").innerHTML = profile.skills.map(skill => `
    <div class="skill-card reveal">
      <div class="skill-top"><span>${esc(skill[index])}</span><span class="skill-pct">${esc(({az:{Advanced:"Qabaqcıl",Foundational:"Baza",Internship:"Təcrübə",Portfolio:"Portfolio"},en:{},ru:{Advanced:"Продвинутый",Foundational:"Базовый",Internship:"Стажировка",Portfolio:"Портфолио"}}[state.lang] || {})[skill[3]] || skill[3])}</span></div>
      
    </div>`).join("");
  $("#softList").innerHTML = profile.soft[state.lang].map(item => `<span class="pill">${esc(item)}</span>`).join("");
}

function renderEducation() {
  $("#educationGrid").innerHTML = profile.education.map(item => `
    <article class="edu-card reveal">
      <div class="edu-tag">${esc(item.tag)}</div>
      <div><h3>${esc(pick(item.title))}</h3><p>${esc(pick(item.desc))}</p></div>
      <small>${esc(pick(item.period))}</small>
    </article>`).join("");
}

function certCategory(tagString) {
  if (tagString.includes("hackerrank")) return "hackerrank";
  if (tagString.includes("sport")) return "sport";
  if (tagString.includes("volunteer")) return "volunteer";
  if (tagString.includes("training")) return "training";
  if (tagString.includes("award")) return "award";
  return "training";
}

function renderFilters() {
  const categories = ["all", "hackerrank", "sport", "volunteer", "training", "award"];
  $("#filters").innerHTML = categories.map(category => `<button type="button" class="filter-btn ${state.filter === category ? "active" : ""}" data-filter="${category}">${esc(tr("filter_" + category))}</button>`).join("");
  $$(".filter-btn").forEach(btn => btn.addEventListener("click", () => { state.filter = btn.dataset.filter; renderFilters(); renderCertificates(); }));
}

function renderCertificates() {
  const query = state.query.trim().toLowerCase();
  const cards = profile.certs.map(cert => {
    const [issuer, title, date, tags] = cert;
    const category = certCategory(String(tags));
    const text = `${pick(issuer)} ${pick(title)} ${date} ${tags}`.toLowerCase();
    const visible = (state.filter === "all" || category === state.filter || String(tags).includes(state.filter)) && (!query || text.includes(query));
    return `
      <article class="cert-card reveal ${visible ? "" : "hidden"}">
        <span class="cert-type">${esc(category)}</span>
        <h3>${esc(pick(issuer))}</h3>
        <p>${esc(pick(title))}</p>
        <footer>${esc(date)}</footer>
      </article>`;
  }).join("");
  $("#certGrid").innerHTML = cards;
}

function renderLetter() {
  $("#letterText").innerHTML = tr("letter").map(p => `<p>${esc(p)}</p>`).join("");
}

function renderContact() {
  const items = [
    [tr("phone"), contact.phone, contact.phoneHref, "☎"],
    [tr("whatsapp"), tr("whatsapp"), contact.whatsappHref, "◉"],
    [tr("email"), contact.email, contact.emailHref, "✉"],
    ["LinkedIn", contact.linkedin, contact.linkedinHref, "in"],
    ["Facebook", contact.facebook, contact.facebookHref, "f"],
    [tr("location"), pick(contact.location), "#contact", "⌖"]
  ];
  $("#contactGrid").innerHTML = items.map(([label, value, href, icon]) => `
    <a class="contact-card" href="${esc(href)}" ${href.startsWith("http") ? 'target="_blank" rel="noreferrer"' : ""}>
      <span class="contact-icon">${esc(icon)}</span>
      <span><small>${esc(label)}</small><strong>${esc(value)}</strong></span>
    </a>`).join("");
}

function revealOnScroll() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add("in"); });
  }, { threshold: .1 });
  $$(".reveal").forEach(el => observer.observe(el));
}

function setLanguage(lang) {
  state.lang = lang;
  localStorage.setItem("portfolio-language", lang);
  renderAll();
}

function renderAll() {
  setText();
  renderStats();
  renderExperiences();
  renderProjects();
  renderSkills();
  renderEducation();
  renderFilters();
  renderCertificates();
  renderLetter();
  renderContact();
  revealOnScroll();
}

document.addEventListener("DOMContentLoaded", () => {
  $("#year").textContent = new Date().getFullYear();
  $$(".lang-btn").forEach(btn => btn.addEventListener("click", () => setLanguage(btn.dataset.lang)));
  $("#printBtn").addEventListener("click", () => window.print());
  $("#certSearch").addEventListener("input", event => { state.query = event.target.value; renderCertificates(); });
  $("#copyLetter").addEventListener("click", async () => {
    const text = tr("letter").join("\n\n");
    try { await navigator.clipboard.writeText(text); $("#copyLetter").textContent = tr("copied"); setTimeout(() => $("#copyLetter").textContent = tr("copy_letter"), 1400); } catch {}
  });
  $("#menuBtn").addEventListener("click", () => {
    const topbar = $(".topbar");
    const open = topbar.classList.toggle("open");
    $("#menuBtn").setAttribute("aria-expanded", String(open));
  });
  $$(".nav a").forEach(link => link.addEventListener("click", () => $(".topbar").classList.remove("open")));
  renderAll();
});

/* Front-end-only 2026 interaction refresh. No portfolio information is changed below. */
document.addEventListener("DOMContentLoaded", () => {
  const root = document.documentElement;
  window.addEventListener("pointermove", event => {
    root.style.setProperty("--mx", `${event.clientX}px`);
    root.style.setProperty("--my", `${event.clientY}px`);
  }, { passive: true });

  const syncActiveNav = () => {
    const links = [...document.querySelectorAll(".nav a")];
    const sections = links
      .map(link => document.querySelector(link.getAttribute("href")))
      .filter(Boolean);
    const onScroll = () => {
      let current = sections[0]?.id;
      for (const section of sections) {
        const rect = section.getBoundingClientRect();
        if (rect.top <= 150) current = section.id;
      }
      links.forEach(link => link.classList.toggle("active", link.getAttribute("href") === `#${current}`));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  };

  const bindCardGlow = () => {
    document.addEventListener("pointermove", event => {
      const card = event.target.closest?.(".project-card");
      if (!card) return;
      const rect = card.getBoundingClientRect();
      card.style.setProperty("--card-x", `${event.clientX - rect.left}px`);
      card.style.setProperty("--card-y", `${event.clientY - rect.top}px`);
    }, { passive: true });
  };

  syncActiveNav();
  bindCardGlow();
});

/* V4 visual layer only: canvas network, subtle 3D tilt and staggered reveals. Content data above remains unchanged. */
document.addEventListener("DOMContentLoaded", () => {
  const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const addNetworkCanvas = () => {
    if (prefersReduced || document.getElementById("matrixCanvas")) return;
    const canvas = document.createElement("canvas");
    canvas.id = "matrixCanvas";
    canvas.setAttribute("aria-hidden", "true");
    document.body.prepend(canvas);
    const ctx = canvas.getContext("2d");
    let width = 0;
    let height = 0;
    let nodes = [];
    const pointer = { x: -9999, y: -9999 };

    const resize = () => {
      width = canvas.width = Math.floor(window.innerWidth * window.devicePixelRatio);
      height = canvas.height = Math.floor(window.innerHeight * window.devicePixelRatio);
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      const count = Math.min(82, Math.max(34, Math.floor(window.innerWidth / 19)));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - .5) * .26 * window.devicePixelRatio,
        vy: (Math.random() - .5) * .26 * window.devicePixelRatio,
        r: (Math.random() * 1.6 + .8) * window.devicePixelRatio
      }));
    };

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      const maxDist = 145 * window.devicePixelRatio;
      const px = pointer.x * window.devicePixelRatio;
      const py = pointer.y * window.devicePixelRatio;
      for (const node of nodes) {
        node.x += node.vx;
        node.y += node.vy;
        if (node.x < 0 || node.x > width) node.vx *= -1;
        if (node.y < 0 || node.y > height) node.vy *= -1;
      }
      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const d = Math.hypot(dx, dy);
          if (d < maxDist) {
            const alpha = (1 - d / maxDist) * .22;
            ctx.strokeStyle = `rgba(102,232,255,${alpha})`;
            ctx.lineWidth = .7 * window.devicePixelRatio;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
        const pd = Math.hypot(a.x - px, a.y - py);
        if (pd < 190 * window.devicePixelRatio) {
          ctx.strokeStyle = `rgba(181,108,255,${(1 - pd / (190 * window.devicePixelRatio)) * .24})`;
          ctx.lineWidth = .8 * window.devicePixelRatio;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(px, py);
          ctx.stroke();
        }
        ctx.fillStyle = "rgba(170,244,255,.78)";
        ctx.beginPath();
        ctx.arc(a.x, a.y, a.r, 0, Math.PI * 2);
        ctx.fill();
      }
      requestAnimationFrame(draw);
    };

    window.addEventListener("resize", resize, { passive: true });
    window.addEventListener("pointermove", event => { pointer.x = event.clientX; pointer.y = event.clientY; }, { passive: true });
    resize();
    draw();
  };

  const addTilt = () => {
    if (prefersReduced) return;
    document.addEventListener("pointermove", event => {
      const card = event.target.closest?.(".project-card, .profile-card, .contact-card, .edu-card");
      if (!card) return;
      const rect = card.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - .5;
      const y = (event.clientY - rect.top) / rect.height - .5;
      const amount = card.classList.contains("profile-card") ? 6 : 3.2;
      card.style.transform = `perspective(900px) rotateX(${(-y * amount).toFixed(2)}deg) rotateY(${(x * amount).toFixed(2)}deg) translateY(-5px)`;
    }, { passive: true });
    document.addEventListener("pointerout", event => {
      const card = event.target.closest?.(".project-card, .profile-card, .contact-card, .edu-card");
      if (card) card.style.transform = "";
    }, { passive: true });
  };

  const addStagger = () => {
    const setDelay = selector => document.querySelectorAll(selector).forEach((el, i) => {
      el.style.transitionDelay = `${Math.min(i * 45, 360)}ms`;
    });
    setDelay(".experience-card");
    setDelay(".project-card");
    setDelay(".skill-card");
    setDelay(".edu-card");
    setDelay(".cert-card");
    setDelay(".contact-card");
  };

  setTimeout(() => {
    addNetworkCanvas();
    addTilt();
    addStagger();
  }, 80);
});
